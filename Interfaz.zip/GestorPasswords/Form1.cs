﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;




namespace GestorPasswords
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string v = textBox1.Text;
            Globales.Usuario = textBox1.Text;
            this.AcceptButton = button2;
            if (v == "")
            {
                label11.Visible = true;
            }
            else
            {
                label11.Visible = false;
                button1.Visible = false;
                v = "Hi " + textBox1.Text;
                labelUser.Visible = true;
                labelUser.Text = v;
                label2.Visible = true;
                textBox2.Visible = true;
                button2.Visible = true;
                button2.TabIndex = 1;
                label1.Visible = false;
                textBox1.Visible = false;
                button1.Visible = false;
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Globales.Password = textBox2.Text;
            Globales.path = @".\" + Globales.Usuario + ".bin";
            label2.Visible = false;
            textBox2.Visible = false;
            button2.Visible = false;
            label1.Visible = false;
            textBox1.Visible = false;
            button1.Visible = false;

            try
            {
                if (File.Exists(Globales.path))
                {
                    string text = "Existing user";
                    MessageBox.Show(text);
                    // Open the stream and read it back.
                    using (StreamReader sr = File.OpenText(Globales.path))
                    {
                        string s = "";
                        int num = 0;
                        while ((s = sr.ReadLine()) != null)
                        {
                            MessageBox.Show(s);
                            num++;
                        }
                        num--;
                        string s1 = num.ToString();
                        s = "Users number: " + s1;
                        MessageBox.Show(s);
                    }
                }
                else
                {
                    // Create the file.

                    using (FileStream fs = File.Create(Globales.path))
                    {

                        string separador = "/";
                        //separador = cifrar (separador, "qaz1wsx2edc3");
                        byte[] info = new UTF8Encoding(true).GetBytes(Globales.Usuario);
                        byte[] info2 = new UTF8Encoding(true).GetBytes(Globales.Password);
                        byte[] separa = new UTF8Encoding(true).GetBytes(separador);

                        // Add some information to the file.
                        fs.Write(info, 0, info.Length);
                        fs.Write(separa, 0, separa.Length);
                        fs.Write(info2, 0, info2.Length);
                        //fs.Write(separa, 0, separa.Length);


                    }

                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            label31.Visible = true;
            label32.Visible = true;
            label33.Visible = true;
            label34.Visible = true;
        }

        public string cifrar(string caracter, string password)
        {
            //throw new NotImplementedException();
            int lonp = password.Length;
            int lonc = caracter.Length;
            string ia, la, ca = "";
            byte bia, bla;
            char[] arr;
            byte[] barr = Encoding.Unicode.GetBytes(caracter); ;
            arr = caracter.ToCharArray();
            int ii;
            for (int i = 0; i < lonc; ++i)
            {
                ia = i.ToString();
                la = lonp.ToString();
                bia = Convert.ToByte(ia);
                bla = Convert.ToByte(la);

                ii = (i % lonp);
                barr[i] = (byte)(barr[i] ^ Convert.ToByte(ii));

            }
            //caracter = 
            return caracter;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }



        private void label32_Click(object sender, EventArgs e)
        {
            //Add user

            label1.Text = "User";
            label1.Visible = true;
            textBox1.Text = "";
            textBox1.Visible = true;
            label2.Text = "Password";
            label2.Visible = true;
            textBox2.Text = "";
            textBox2.Visible = true;
            button3.Visible = true;



        }
        private void label34_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label31_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            using (StreamReader sr = File.OpenText(Globales.path))
            {
                string s = "";
                //string[,] lineas = new string[100, 2];

                int num = 0;
                while ((s = sr.ReadLine()) != null)
                {
                    string s3 = num.ToString();
                    //lineas[num, 0] = s3;
                    //lineas[num, 1] = s;
                    int testPos, lon;
                    int start = 0;
                    testPos = s.IndexOf('/', start);
                    lon = s.Length;
                    s = s.Remove(testPos, lon - testPos);
                    string s2 = s3 + " / " + s;
                    if (num == 0)
                    {
                        listBox1.Visible = true;

                    }
                    else
                    {
                        listBox1.Items.Add(s2);
                    }
                    //MessageBox.Show(s2);
                    num++;
                }

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int num = 0;
            string separador = "/";
            string s = "";
            string[] lineas = new string[100];
            Globales.Usuariog = textBox1.Text;
            Globales.Passwordg = textBox2.Text;
            listBox1.Items.Clear();
            using (StreamReader sr = File.OpenText(Globales.path))
            {


                string s3 = num.ToString();
                while ((s = sr.ReadLine()) != null)
                {
                    s3 = num.ToString();
                    lineas[num] = s;
                    int testPos, lon;
                    int start = 0;
                    testPos = s.IndexOf('/', start);
                    lon = s.Length;
                    s = s.Remove(testPos, lon - testPos);
                    string s2 = s3 + " / " + s;
                    if (num == 0)
                    {
                        listBox1.Visible = true;

                    }
                    else
                    {
                        listBox1.Items.Add(s2);
                    }
                    //MessageBox.Show(s2);
                    num++;
                }

            }




            using (FileStream fs = File.OpenWrite(Globales.path))
            {
                string salto = "\n";
                byte[] saltoinfo = new UTF8Encoding(true).GetBytes(salto);
                for (int i = 0; i < num;)
                {
                    byte[] rinfo = new UTF8Encoding(true).GetBytes(lineas[i]);

                    // Add some information to the file.

                    fs.Write(rinfo, 0, rinfo.Length);
                    fs.Write(saltoinfo, 0, saltoinfo.Length);
                    i++;
                }



                int numw = 0;
                string s3 = "";
                //s3 = Globales.numg.ToString;
                //int num = Globales.numg;
                s3 = numw.ToString();
                s = Globales.Usuariog;
                string s2 = s3 + " / " + s;
                listBox1.Items.Add(s2);




                //separador = cifrar (separador, "qaz1wsx2edc3");
                byte[] info = new UTF8Encoding(true).GetBytes(Globales.Usuariog);
                byte[] info2 = new UTF8Encoding(true).GetBytes(Globales.Passwordg);
                byte[] separa = new UTF8Encoding(true).GetBytes(separador);


                // Add some information to the file.
                fs.Write(info, 0, info.Length);
                fs.Write(separa, 0, separa.Length);
                fs.Write(info2, 0, info2.Length);
                fs.Write(saltoinfo, 0, saltoinfo.Length);


                label1.Visible = false;
                textBox1.Text = "";
                textBox1.Visible = false;

                label2.Visible = false;
                textBox2.Text = "";
                textBox2.Visible = false;
                button3.Visible = false;



            }

        }

        private void label33_Click(object sender, EventArgs e)
        {
            buttonBorrar.Visible = true;
            labelBorrar.Visible = true;
        }

        private void buttonBorrar_Click(object sender, EventArgs e)
        {
            string curItem = listBox1.SelectedItem.ToString();
            int index = listBox1.FindString(curItem);

            int num = 0;
            string separador = "/";
            string s = "";
            string sl = "";
            string[] lineas = new string[100];
            Globales.Usuariog = textBox1.Text;
            Globales.Passwordg = textBox2.Text;
            listBox1.Items.Clear();
            using (StreamReader sr = File.OpenText(Globales.path))
            {


                string s3 = num.ToString();
                while ((s = sr.ReadLine()) != null)
                {
                    s3 = num.ToString();
                   
                    
                    int testPos, lon;
                    int start = 0;
                    testPos = s.IndexOf('/', start);
                    lon = s.Length;
                    sl = s.Remove(testPos, lon - testPos);
                    string s2 = s3 + " / " + sl;
                    if (num == 0)
                    {
                        listBox1.Visible = true;

                    }
                    else
                    {
                        listBox1.Items.Add(s2);
                    }
                    //MessageBox.Show(s2);
                    if (num != (index+1))
                    {
                        lineas[num] = s;
                        num++;
                    }
                    else { index=0; }
                    
                    
                }
                listBox1.Visible=false;
            }
            


            using (FileStream fs = File.OpenWrite(Globales.path))
            {
                string salto = "\n";
                byte[] saltoinfo = new UTF8Encoding(true).GetBytes(salto);
                for (int i = 0; i < num;)
                {
                    byte[] rinfo = new UTF8Encoding(true).GetBytes(lineas[i]);

                    // Add some information to the file.

                    fs.Write(rinfo, 0, rinfo.Length);
                    fs.Write(saltoinfo, 0, saltoinfo.Length);
                    i++;
                }








              
            }
        }

    }
    }
